package com.webflow2book;

/**
 * Interface for a payment option
 * @author Sven
 */
public interface Payment {
    // Empty for now
}
